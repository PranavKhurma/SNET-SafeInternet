# AetherAI Backend

This is the backend service for AetherAI, handling transcription, severity scoring, and data storage.

## Installation
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run the backend: `python app.py`
