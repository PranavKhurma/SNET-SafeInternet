import azure.cognitiveservices.speech as speechsdk

def transcribe_audio(audio_file):
    speech_config = speechsdk.SpeechConfig(subscription='your_key', region='your_region')
    audio_config = speechsdk.AudioConfig(filename=audio_file)
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
    result = recognizer.recognize_once()
    return result.text if result.reason == speechsdk.ResultReason.RecognizedSpeech else ""
