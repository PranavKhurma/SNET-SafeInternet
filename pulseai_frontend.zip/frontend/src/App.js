import React, { useState } from 'react';

function App() {
    const [file, setFile] = useState(null);
    const [transcript, setTranscript] = useState('');
    const [severity, setSeverity] = useState(0);
    
    const handleUpload = async () => {
        const formData = new FormData();
        formData.append('audio', file);
        const response = await fetch('/transcribe', { method: 'POST', body: formData });
        const data = await response.json();
        setTranscript(data.transcript);
        setSeverity(data.severity);
    };
    
    return (
        <div>
            <h1>AetherAI</h1>
            <input type="file" onChange={(e) => setFile(e.target.files[0])} />
            <button onClick={handleUpload}>Upload</button>
            <p>Transcript: {transcript}</p>
            <p>Severity: {severity}</p>
        </div>
    );
}

export default App;
