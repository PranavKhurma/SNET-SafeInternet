from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from model import predict_severity
from transcribe import transcribe_audio

app = Flask(__name__)
app.config['MONGO_URI'] = 'your_mongodb_connection_string'
mongo = PyMongo(app)

@app.route('/transcribe', methods=['POST'])
def transcribe():
    audio_file = request.files['audio']
    text = transcribe_audio(audio_file)
    severity = predict_severity(text)
    mongo.db.calls.insert_one({"transcript": text, "severity": severity})
    return jsonify({"transcript": text, "severity": severity})

if __name__ == '__main__':
    app.run(debug=True)
