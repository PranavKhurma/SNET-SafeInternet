# AetherAI Frontend

AetherAI is an AI-powered emergency call triage system designed to assist dispatchers.

## Features
- Real-time transcription of emergency calls
- Multilingual support
- Machine learning-based severity scoring
- Priority-based call ranking
- Scalable deployment with Kubernetes

## Installation
1. Clone the repository
2. Install dependencies: `npm install`
3. Start the frontend: `npm start`
